import { useEffect, useRef, useState } from "react"
import { hasCookieConsent } from "./CookieConsent"

declare global {
  interface Window {
    atOptions?: {
      key: string
      format: "iframe"
      height: number
      width: number
      params: Record<string, unknown>
    }
  }
}

type ExternalAdVariant = "tower" | "smallTower" | "banner"

const ads: Record<ExternalAdVariant, { key: string; height: number; width: number }> = {
  tower: { key: "10a59e47b41d9889deb284ab5a0bf460", height: 600, width: 160 },
  smallTower: { key: "4bab395f72e708783efcfb02fe5691da", height: 300, width: 160 },
  banner: { key: "22289a83ef12e80a727a939faa1b5fa9", height: 60, width: 468 },
}

export function ExternalAdSlot({ variant, className = "" }: { variant: ExternalAdVariant; className?: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const ad = ads[variant]
  const [consented, setConsented] = useState(hasCookieConsent)
  const [adUnavailable, setAdUnavailable] = useState(false)

  useEffect(() => {
    const onConsent = () => setConsented(hasCookieConsent())
    window.addEventListener("omnicalc:consent", onConsent)
    return () => window.removeEventListener("omnicalc:consent", onConsent)
  }, [])

  useEffect(() => {
    const container = containerRef.current
    if (!container || !consented) return

    container.replaceChildren()
    setAdUnavailable(false)
    window.atOptions = {
      key: ad.key,
      format: "iframe",
      height: ad.height,
      width: ad.width,
      params: {},
    }

    const script = document.createElement("script")
    script.async = true
    script.src = `https://www.highrevenueformat.com/${ad.key}/invoke.js`
    script.dataset.omnicalcAd = variant
    container.appendChild(script)
    const timeout = window.setTimeout(() => {
      setAdUnavailable(!container.querySelector("iframe, ins"))
    }, 2500)

    return () => {
      window.clearTimeout(timeout)
      if (container) container.replaceChildren()
    }
  }, [ad.height, ad.key, ad.width, variant, consented])

  return (
    <div
      ref={containerRef}
      className={`ad-frame ad-frame-${variant} flex w-full items-center justify-center overflow-hidden ${className}`}
      style={{ minHeight: ad.height }}
      aria-label="Advertisement"
      data-consent-required={!consented}
      data-ad-provider="highrevenueformat"
    >
      {consented && adUnavailable && (
        <span className="px-3 text-center text-xs text-muted-foreground">
          Ads may be unavailable. Please check your ad-blocker settings if you would like to support this free tool.
        </span>
      )}
      {!consented && <span className="px-3 text-center text-xs text-muted-foreground">Ads load after your consent.</span>}
    </div>
  )
}

export function ExternalAdLink({ className = "" }: { className?: string }) {
  return (
    <a
      href="https://www.profitableratecpmnetwork.com/pfbttupu?key=515a9c09c701f9b9742eef1e40093239"
      target="_blank"
      rel="nofollow sponsored noopener noreferrer"
      className={`ad-smartlink block text-center text-xs text-muted-foreground underline-offset-4 hover:underline ${className}`}
    >
      Sponsored link
    </a>
  )
}
